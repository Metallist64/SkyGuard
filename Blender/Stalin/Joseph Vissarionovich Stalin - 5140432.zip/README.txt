Joseph Vissarionovich Stalin by WhDr on Thingiverse: https://www.thingiverse.com/thing:5140432

Summary:
Bust of Joseph Vissarionovich StalinSeveral options.you can print without supports.my printing without supports was successful.